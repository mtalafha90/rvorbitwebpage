import os
import uuid
import shutil
import traceback
from pathlib import Path

from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash
from werkzeug.utils import secure_filename

# Ensure Matplotlib is non-interactive on servers
import matplotlib
matplotlib.use("Agg")

import backend  # your original code (renamed)

APP_DIR = Path(__file__).resolve().parent
RUNS_DIR = APP_DIR / "runs"
RUNS_DIR.mkdir(exist_ok=True)

ALLOWED_EXTENSIONS = {".inp", ".csv", ".txt"}

def allowed_file(filename: str) -> bool:
    return Path(filename).suffix.lower() in ALLOWED_EXTENSIONS

def save_fig(fig, path: Path):
    fig.savefig(path, dpi=160, bbox_inches="tight")
    try:
        import matplotlib.pyplot as plt
        plt.close(fig)
    except Exception:
        pass

def run_fit_to_dir(run_dir: Path, uploaded_path: Path, fixel_map: dict[str, int]) -> dict:
    """
    Executes: readinp/readcsv_custom -> set fixel -> fitorb -> orbsave -> plots
    All outputs written into run_dir.
    Returns summary dict for templating.
    """
    cwd = os.getcwd()
    os.chdir(run_dir)
    try:
        ext = uploaded_path.suffix.lower()
        if ext == ".inp":
            backend.readinp(str(uploaded_path))
        else:
            if hasattr(backend, "readcsv_custom"):
                backend.readcsv_custom(str(uploaded_path))
            else:
                raise RuntimeError("CSV upload not supported: backend.readcsv_custom not found in backend.py")

        # Apply fixel (1=fit, 0=fixed)
        for i, nm in enumerate(list(backend.orb.elname)):
            backend.orb.fixel[i] = int(fixel_map.get(nm, 1))

        backend.fitorb()
        backend.orbsave()

        stem = Path(backend.orb.obj.get("fname", uploaded_path.name)).stem
        output_csv = f"{stem}_output.csv"
        output_csv_path = run_dir / output_csv

        plot_files = []
        if hasattr(backend, "orbplot_streamlit"):
            figs = backend.orbplot_streamlit()
            for idx, fig in enumerate(figs, start=1):
                p = run_dir / f"plot_{idx}.png"
                save_fig(fig, p)
                plot_files.append(p.name)

        residual_file = None
        if int(backend.orb.obj.get("npos", 0)) > 0 and hasattr(backend, "residual_plots"):
            fig = backend.residual_plots()
            p = run_dir / "residuals.png"
            save_fig(fig, p)
            residual_file = p.name

        elements = []
        for i, nm in enumerate(list(backend.orb.elname)):
            elements.append({
                "name": nm,
                "value": float(backend.orb.el[i]),
                "err": float(getattr(backend.orb, "elerr", [0]*10)[i]),
                "fit": int(backend.orb.fixel[i]),
            })

        obj = backend.orb.obj
        stats = {
            "name": obj.get("name", ""),
            "npos": int(obj.get("npos", 0)),
            "nrv1": int(obj.get("nrv1", 0)),
            "nrv2": int(obj.get("nrv2", 0)),
            "parallax": float(obj.get("parallax", 0.0)),
            "chi2": float(obj.get("chi2", 0.0)),
        }
        try:
            chi2n = obj.get("chi2n", [0,0,0,0])
            rms = obj.get("rms", [0,0,0,0])
            stats.update({
                "chi2n_theta": float(chi2n[0]),
                "chi2n_rho": float(chi2n[1]),
                "chi2n_rv1": float(chi2n[2]),
                "chi2n_rv2": float(chi2n[3]),
                "rms_theta": float(rms[0]),
                "rms_rho": float(rms[1]),
                "rms_rv1": float(rms[2]),
                "rms_rv2": float(rms[3]),
            })
        except Exception:
            pass

        return {
            "run_id": run_dir.name,
            "elements": elements,
            "stats": stats,
            "plot_files": plot_files,
            "residual_file": residual_file,
            "output_csv": output_csv if output_csv_path.exists() else None,
        }
    finally:
        os.chdir(cwd)

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "change-me")

@app.route("/", methods=["GET"])
def index():
    elnames = list(getattr(backend, "orb").elname)
    defaults = {nm: 1 for nm in elnames}
    return render_template("index.html", elnames=elnames, defaults=defaults)

@app.route("/run", methods=["POST"])
def run():
    try:
        if "datafile" not in request.files:
            flash("No file selected.", "error")
            return redirect(url_for("index"))

        f = request.files["datafile"]
        if not f.filename:
            flash("No file selected.", "error")
            return redirect(url_for("index"))

        if not allowed_file(f.filename):
            flash("Unsupported file type. Upload .inp, .csv, or .txt", "error")
            return redirect(url_for("index"))

        run_id = uuid.uuid4().hex[:12]
        run_dir = RUNS_DIR / run_id
        run_dir.mkdir(parents=True, exist_ok=True)

        filename = secure_filename(f.filename)
        uploaded_path = run_dir / filename
        f.save(uploaded_path)

        elnames = list(getattr(backend, "orb").elname)
        fixel_map = {nm: (1 if request.form.get(f"fit_{nm}") == "on" else 0) for nm in elnames}

        summary = run_fit_to_dir(run_dir, uploaded_path, fixel_map)
        return render_template("result.html", **summary)
    except Exception as e:
        tb = traceback.format_exc()
        flash(f"Fit failed: {e}", "error")
        return render_template("error.html", error=str(e), traceback=tb)

@app.route("/runs/<run_id>/<path:filename>")
def run_file(run_id, filename):
    run_dir = RUNS_DIR / run_id
    return send_from_directory(run_dir, filename, as_attachment=False)

@app.route("/download/<run_id>/<path:filename>")
def download(run_id, filename):
    run_dir = RUNS_DIR / run_id
    return send_from_directory(run_dir, filename, as_attachment=True)

@app.route("/cleanup/<run_id>", methods=["POST"])
def cleanup(run_id):
    run_dir = RUNS_DIR / run_id
    if run_dir.exists():
        shutil.rmtree(run_dir, ignore_errors=True)
    flash("Run directory cleaned up.", "info")
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8000, debug=True)
